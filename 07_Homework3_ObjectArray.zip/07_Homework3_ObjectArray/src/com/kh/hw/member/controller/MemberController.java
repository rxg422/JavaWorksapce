package com.kh.hw.member.controller;

import com.kh.hw.member.model.vo.Member;

public class MemberController {

	public static final int SIZE = 10;
	private Member m[] = new Member[SIZE];
	private int size=0;
	
	public int existMemberNum() {
		return size;
	}
	
	public boolean checkId(String id) {
		for(Member mem : m) {
			if(mem==null) {
				return false;
			}
			if(mem.getId().equals(id)) {
				return true;
			}
		}
		
		return true;
	}
	
	public void insertMember(String id, String name, String password, String email, char gender, int age) {
		Member mem = new Member(id, name, password, email, gender, age);
		
		System.out.println(size);
		m[size] = mem;
		
		size++;
		System.out.println(size);
	}
	
	public String searchId(String id) {
		for(Member mem : m) {
			if(mem==null) {
				return null;
			}
			if(mem.getId().equals(id)) {
				return mem.information();
			}
		}
		
		return null;
	}
	
	public Member[] searchName(String name) {
		Member mp[] = new Member[SIZE];
		
		for(int i=0; m[i]!=null; i++) {
			if(m[i].getName().equals(name)) {
				mp[i] = m[i];
			}
		}
		
		return mp;
	}
	
	public Member[] searchEmail(String email) {
		Member mp[] = new Member[SIZE];
		
		for(int i=0; m[i]!=null; i++) {
			if(m[i].getEmail().equals(email)) {
				mp[i] = m[i];
			}
			mp[i] = m[i];
		}
		
		return mp;
	}
	
	public boolean updatePassword(String id, String password) {
		for(int i=0; m[i]!=null; i++) {
			if(m[i].getId().equals(id)) {
				m[i].setPassword(password);
				return true;
			}
		}
		return true;
	}
	
	public boolean updateName(String id, String name) {
		for(int i=0; i<SIZE; i++) {
			if(m[i].getId().equals(id)) {
				m[i].setName(name);
				return true;
			}
		}
		return true;
	}
	
	public boolean updateEmail(String id, String email) {
		for(int i=0; m[i]!=null; i++) {
			if(m[i].getId().equals(id)) {
				m[i].setEmail(email);
				return true;
			}
		}
		return true;
	}
	
	public boolean delete(String id) {
		Member copy[] = new Member[SIZE];
		for(int i=0; m[i]!=null; i++) {
			if(m[i].getId().equals(id)) {
				System.arraycopy(m, 0, copy, 0, i);
				System.arraycopy(m, i+1, copy, i, SIZE-i-1);
				m = copy;
				size--;
				return true;
			}
		}
		return false;
	}
	
	public void delete() {
		for(int i=0; i<SIZE; i++) {
			m[i] = null;
		}
		size = 0;
	}
	
	public Member[] printAll() {
		return m;
	}
	
}
